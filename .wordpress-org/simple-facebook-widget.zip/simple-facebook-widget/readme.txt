=== Simple Facebook Widget ===

Contributors: monjurulhoque
Creator's website link: http://monjurulhoque.com/
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=G7YTKMJYS4T92


Requires at least: 3.0.1
Tested up to: 4.4.1
Stable tag: 1.0


Author: Monjurul Hoque

Author URI: http://www.monjurulhoque.com

Plugin URI: http://www.monjurulhoque.com

Author Name : Monjurul Hoque

Author URL : http://www.monjurulhoque.com

Tags: simple facebook widget, facebook widget, facebook profile widget, facebook page widget

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple Facebook Widget Plugin lets you easily embed and promote your Facebook Page on your website. You can easily collect fan for your pages.

== Description ==
Simple Facebook Widget Plugin lets you easily embed and promote your Facebook Page on your website. You can easily collect fan for your pages.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the `Simple-Facebook-Widget` folder to the to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the Facebook Page URL to this plugins from the widgets window in WordPress admin panel.
4. Configure the available options with your page type, URL, desired style and size.
- Enjoy!



== Frequently Asked Questions ==
Contact us for any kind of support.
Visit My Site - http://www.monjurulhoque.com
You Can Mail me - info[at]saucerweb.com

== Screenshots ==

== Changelog ==